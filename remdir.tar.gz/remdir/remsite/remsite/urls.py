"""remsite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import include, url
from django.contrib import admin
from rapp import views

urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^home/',views.home,name='home'),
    url(r'^create/',views.create,name='create'),
    url(r'^update/',views.update,name='update'),
 #   url(r'^update2/',views.update2,name='update2'),
    url(r'^f1/',views.f1,name='f1'),
    url(r'^f3/',views.f3,name='f3'),
    url(r'^f4/',views.f4,name='f4'),
    url(r'^f2/',views.f2,name='f2'),
]
