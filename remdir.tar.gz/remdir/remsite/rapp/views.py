from django.shortcuts import render
# Create your views here.
from django.http import HttpResponse
from django.shortcuts import render_to_response
from rapp.models import t1

def home(request):
    return render(request,'home.html')

def create(request):
    return render(request,'create.html')
    
def view(request):
    return render(request,'table.html')
    
    
def update(request):
    x=t1.objects.all()
    return render_to_response('update.html',{'u1':x })
    #return render(request,'update.html')
    
    
    
def f1(request):
    l=float(request.GET['Time'])
    m=request.GET['Message']
    n=request.GET['Date']
    p=t1(time=l,date=n,msg=m)
    p.save()
    return render(request,'home.html')
    
    
def f2(request):
    global u
    l=float(request.GET['id'])
    n=request.GET['date']
    u=t1.objects.get(time=l)
    if(u.time==l and u.date==n):
        return render(request,'update2.html')
   	
    
    
def f3(request):
    x=t1.objects.all()
    return render_to_response('table.html',{'u1':x })
    
    
    
def f4(request):
    l=request.GET['Time']
    m=request.GET['Message']
    n=request.GET['Date']
    u.time=l
    u.date=n
    u.msg=m
    u.save()
    return render(request,'home.html')
    

