from django.db import models

# Create your models here.
class t1(models.Model):
     time=models.FloatField(max_length=20)
     date=models.CharField(max_length=20)
     msg=models.CharField(max_length=20)
